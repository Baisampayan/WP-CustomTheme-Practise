import $ from 'jquery';         // Using '$' instead of jquery
import './components/slider.js';
import './components/navigation'

let x = 0;
console.log(x);


// Using '$' instead of jquery
// $('body').click(()=>{
//     alert('Hi');
// })