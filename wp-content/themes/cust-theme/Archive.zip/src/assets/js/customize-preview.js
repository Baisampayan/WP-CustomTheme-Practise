import $ from 'jquery';
import strip_tags from './helpers/strip-tags';

// console.log(wp);
wp.customize('_themename_site_info', (value) => {
    value.bind((to) => {
        // console.log(to);
        $('.c-site-info__text').html(strip_tags(to, '<a>'));
    })
})

wp.customize('_themename_accent_color', (value) => {
    value.bind((to) => {
        $('#_themename-stylesheet-inline-css').html(
            `
            a, a:active, .header-nav .menu > .menu-item.mega > .sub-menu > .menu-item > a:hover, .header-nav .menu > .menu-item.mega > .sub-menu > .menu-item > .sub-menu a:hover {
                color: ${to};
            }

            .c-post.sticky {
                border-left: ${to};
            }

            .c-post.format-quote blockquote, .c-post.format-link .c-post__excerpt p, button, input[type=submit], .c-footer-widget .tagcloud a, .navigation.pagination .nav-links a:hover {
                background-color: ${to};
            }

            :focus {
                outline-color: ${to};
            }

            ::selection, ::-moz-selection {
                background: ${to} !important;
            }

            .header-nav .menu > .menu-item:not(.mega) .sub-menu .menu-item:hover > a  {
                background-color: ${to} !important;
            }
        `
        );
    })
})