<?php
function custtheme_assets() {
    wp_enqueue_style( 'custtheme-stylesheet', get_template_directory_uri( ) . '/dist/assets/css/bundle.css', array(), '1.0.0', 'all' );
    wp_enqueue_script( 'custtheme-script', get_template_directory_uri(  ) . '/dist/assets/js/bundle.js', array('jquery'), '1.0.0', true );
}

add_action( 'wp_enqueue_scripts', 'custtheme_assets' );

function custtheme_admin_assets() {
    wp_enqueue_style( 'custtheme-admin_stylesheet', get_template_directory_uri( ) . '/dist/assets/css/admin.css', array(), '1.0.0', 'all' );
    wp_enqueue_script( 'custtheme-admin-script', get_template_directory_uri(  ) . '/dist/assets/js/admin.js', array(), '1.0.0', true );
}

add_action( 'admin_enqueue_scripts', 'custtheme_admin_assets' );