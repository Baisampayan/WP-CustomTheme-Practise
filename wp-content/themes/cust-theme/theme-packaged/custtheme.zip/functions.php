<?php

require_once('lib/helpers.php');
require_once('lib/assets.php');
require_once('lib/sidebars.php');

function after_pagination() {
    echo "This is after pagination";
}

function after_pagination2() {
    echo "This is after pagination Text";
}

add_action( 'custtheme_after_pagination', 'after_pagination', 2 );
add_action( 'custtheme_after_pagination', 'after_pagination2', 1 );

// Adding Code to WordPress Default Hooks & Action
//add_action( 'wp_head', 'function_to_add_in_wp_head' );

// function function_to_add_in_wp_head() {
//     echo "<style>body{background-color: #fff !important;}</style>";
// }